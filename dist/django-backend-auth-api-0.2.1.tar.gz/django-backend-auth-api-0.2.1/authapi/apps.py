from django.apps import AppConfig


class AuthapiConfig(AppConfig):
    name = 'authapi'
